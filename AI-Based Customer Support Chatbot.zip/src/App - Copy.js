import React, { useState } from 'react';
import './App.css';

// Project Data Compiled From Week 1 to Week 4
const projectData = {
  title: "AI-Based Customer Support Chatbot",
  lead: "Dharmendra Kumar Nayak",
  startDate: "10/04/2026",
  currentDate: "24/04/2026",
  globalStatus: "IN PROGRESS / VALIDATION",
  overallProgress: 75,
  weeks: [
    {
      id: 1,
      title: "Week 1: Planning & Scope",
      status: "COMPLETED",
      tagline: "Initial Planning & Requirement Analysis",
      metrics: [
        { label: "Initial Progress", value: "0% -> 100%" },
        { label: "Scope Definition", value: "In vs Out of Scope" },
        { label: "Availability Target", value: "24/7 Automation" }
      ],
      content: {
        summary: "This initial phase established the technical and functional boundaries of the chatbot. The core objective is reducing operational load by triaging routine inquiries and routing complex edge cases.",
        deliverables: [
          "Objective Definition & Scoping: Focus on reducing ticket volumes for human agents.",
          "High-Level Requirements: Specifying NLP constraints, 24/7 availability matrix, and handover workflows.",
          "Data Gathering: Harvesting FAQ Repositories, historical chat logs, and evaluating AI frameworks (Rasa, Dialogflow, OpenAI API)."
        ],
        table: [
          { team: "AI Development", responsibility: "Identify NLP models & architectural constraints", status: "Done" },
          { team: "Customer Support", responsibility: "Provide 'Ground Truth' QA data sets", status: "Done" },
          { team: "IT Infrastructure", responsibility: "Assess server requirements & integration architecture", status: "Done" }
        ]
      }
    },
    {
      id: 2,
      title: "Week 2: Architecture",
      status: "COMPLETED",
      tagline: "Logic Mapping & Decision Tree Frameworks",
      metrics: [
        { label: "Logic Matrix", value: "Completed" },
        { label: "Environment", value: "Configured" },
        { label: "Data Pipelines", value: "Mapped" }
      ],
      content: {
        summary: "Bridge phase transitioning structural goals into algorithmic logic maps. Finalized requirement documentation, designed core intent trees, and initialized the base dev pipelines.",
        deliverables: [
          "Decision Tree Mapping: Visualizing routing layouts for context tracking.",
          "Dev Environment Setup: Securing repo structures and container base layers.",
          "Specification Finalization: Sign-offs from Customer Support stakeholders on core conversational workflows."
        ],
        table: [
          { team: "AI Development", responsibility: "Intent mapping and entity breakdown design", status: "Done" },
          { team: "Customer Support", responsibility: "Review conversational trees for tone and compliance", status: "Done" },
          { team: "IT Infrastructure", responsibility: "Staging sandbox server procurement", status: "Done" }
        ]
      }
    },
    {
      id: 3,
      title: "Week 3: Prototyping",
      status: "COMPLETED",
      tagline: "Integration Setup & Alpha Prototype Build",
      metrics: [
        { label: "RAG Pipeline", value: "Connected" },
        { label: "API Framework", value: "FastAPI" },
        { label: "Vector DB", value: "Chroma/Pinecone" }
      ],
      content: {
        summary: "Focuses on Integration Setup and Prototype Development. Establishes the communication bridge between the AI core and the user-facing interface, ensuring optimized vector data flows securely.",
        deliverables: [
          "Integration Infrastructure: Successfully linked LLM layers to Vector DBs for real-time context-aware retrieval.",
          "API Architecture: Deployed secure RESTful endpoints using FastAPI to handle highly concurrent asynchronous chat requests.",
          "Database Linkage: Indexed historical FAQ logs and system query files directly into the active retrieval layers."
        ],
        table: [
          { team: "AI Development", responsibility: "RAG Pipeline setup & API endpoint creation", status: "Completed" },
          { team: "Frontend Dev", responsibility: "JavaScript Chat UI implementation with loading states", status: "Completed" },
          { team: "IT Infrastructure", responsibility: "Server environment & CORS policy configuration", status: "In Progress" }
        ],
        code: `async function getBotResponse(userText) {
  const response = await fetch('http://api.chatbot.internal/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: userText })
  });
  const data = await response.json();
  appendMessage(data.response, "bot");
}`
      }
    },
    {
      id: 4,
      title: "Week 4: QA & Testing",
      status: "IN PROGRESS",
      tagline: "Validation, Edge Case Tuning & Sentiment Analysis",
      metrics: [
        { label: "RAG Accuracy", value: "92%" },
        { label: "Avg Latency", value: "1.2 seconds" },
        { label: "Handoff Logic", value: "100% Success" }
      ],
      content: {
        summary: "Rigorous validation of the Alpha prototype created in Week 3. This phase guarantees system stability, context preservation, and data isolation before external user routing begins.",
        deliverables: [
          "Functional Testing: Verifying chatbot response accuracy metrics against ground-truth FAQ records.",
          "Security Validation: Auditing JWT/OAuth2 layers to completely isolate personal user records during execution queries.",
          "Performance Benchmarking: Hammering ingestion clusters under simulated high-load conditions to find limits."
        ],
        table: [
          { team: "AI / Core QA", responsibility: "Algorithmic temperature modifications & vector scoring", status: "In Progress" },
          { team: "SecOps", responsibility: "JWT and penetration handling of endpoint assets", status: "In Progress" },
          { team: "Product Team", responsibility: "UAT testing loops with selected internal staff", status: "In Progress" }
        ],
        code: `// Sentiment Escalation Protocol
if (sentimentScore < -0.75 || retryCount > 3) {
  await triggerHumanAgentHandoff(sessionId);
  return "I'm connecting you to a specialist now.";
}`
      }
    }
  ]
};

export default function App() {
  const [activeTab, setActiveTab] = useState(4); // Default to latest active phase (Week 4)
  const [chatMessages, setChatMessages] = useState([
    { text: "Hello! Testing the Week 4 system. How fast are you?", sender: "user" },
    { text: "System response checked. My current average retrieval latency is 1.2 seconds with a 92% accuracy rating.", sender: "bot" },
    { text: "I'm totally frustrated with my connection!", sender: "user" },
    { text: "🚨 [Sentiment Score Detected < -0.75] I'm connecting you to a specialist now.", sender: "bot", special: true }
  ]);
  const [inputMessage, setInputMessage] = useState("");

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const newMessages = [...chatMessages, { text: inputMessage, sender: "user" }];
    setChatMessages(newMessages);
    setInputMessage("");

    // Simple reactive chat responses to make dashboard interactive
    setTimeout(() => {
      if (inputMessage.toLowerCase().includes('help') || inputMessage.toLowerCase().includes('bad')) {
        setChatMessages(prev => [...prev, { 
          text: "🚨 [Trigger: Sentiment Escalation] System routing to live support representative...", 
          sender: "bot", 
          special: true 
        }]);
      } else {
        setChatMessages(prev => [...prev, { 
          text: "Data parsed successfully. Context-aware RAG pipeline simulation online.", 
          sender: "bot" 
        }]);
      }
    }, 800);
  };

  const currentWeekData = projectData.weeks.find(w => w.id === activeTab);

  return (
    <div className="dashboard-container">
      {/* HEADER BAR */}
      <header className="main-header">
        <div className="logo-section">
          <div className="pulse-indicator"></div>
          <div>
            <h1>{projectData.title}</h1>
            <p className="subtitle">Project Lead: <strong>{projectData.lead}</strong> | Baseline: 2026</p>
          </div>
        </div>
        <div className="global-status-badge">
          <span className="status-label">GLOBAL PHASE:</span>
          <span className="status-value">{projectData.globalStatus}</span>
        </div>
      </header>

      {/* OVERVIEW STAT CARDS */}
      <section className="stats-grid">
        <div className="stat-card gold">
          <div className="stat-icon">📈</div>
          <div className="stat-info">
            <h4>Total Completion</h4>
            <h3>{projectData.overallProgress}%</h3>
            <div className="progress-bar-container">
              <div className="progress-bar-fill" style={{ width: `${projectData.overallProgress}%` }}></div>
            </div>
          </div>
        </div>
        <div className="stat-card text-blue">
          <div className="stat-icon">🗓️</div>
          <div className="stat-info">
            <h4>Current Lifecycle</h4>
            <h3>Week 4 Validation</h3>
            <p>Next: 10% Live Traffic Beta</p>
          </div>
        </div>
        <div className="stat-card text-green">
          <div className="stat-icon">⚡</div>
          <div className="stat-info">
            <h4>Avg Response Speed</h4>
            <h3>1.2 Seconds</h3>
            <p>Target Goal: &lt; 1.5s</p>
          </div>
        </div>
        <div className="stat-card text-purple">
          <div className="stat-icon">🎯</div>
          <div className="stat-info">
            <h4>RAG Query Relevance</h4>
            <h3>92% Accuracy</h3>
            <p>Baseline Target: 90%</p>
          </div>
        </div>
      </section>

      {/* MAIN TWO-COLUMN CONTENT */}
      <div className="main-layout">
        
        {/* LEFT COLUMN: TIMELINE VIEWER */}
        <main className="content-area">
          <div className="card timeline-card">
            <div className="card-header">
              <h2>📅 Project Roadmap & Phase Logs</h2>
              <div className="tab-navigation">
                {projectData.weeks.map(w => (
                  <button 
                    key={w.id} 
                    className={`tab-btn ${activeTab === w.id ? 'active' : ''}`}
                    onClick={() => setActiveTab(w.id)}
                  >
                    W{w.id}
                  </button>
                ))}
              </div>
            </div>

            <div className="tab-viewport">
              <div className="viewport-title-block">
                <h3>{currentWeekData.title}</h3>
                <span className={`badge ${currentWeekData.status.toLowerCase().replace(' ', '-')}`}>
                  {currentWeekData.status}
                </span>
              </div>
              <p className="tagline-text"><em>"{currentWeekData.tagline}"</em></p>
              
              <hr className="divider" />

              <h4>Summary Matrix</h4>
              <p className="summary-desc">{currentWeekData.content.summary}</p>

              <div className="mini-metrics-grid">
                {currentWeekData.metrics.map((m, i) => (
                  <div key={i} className="mini-metric-pill">
                    <span className="pill-label">{m.label}:</span>
                    <span className="pill-val">{m.value}</span>
                  </div>
                ))}
              </div>

              <h4>Key Deliverables</h4>
              <ul className="deliverables-list">
                {currentWeekData.content.deliverables.map((item, index) => (
                  <li key={index}>{item}</li>
                ))}
              </ul>

              <h4>Resource Deployment Matrix</h4>
              <div className="table-wrapper">
                <table className="custom-table">
                  <thead>
                    <tr>
                      <th>Team Division</th>
                      <th>Primary Strategic Responsibility</th>
                      <th>Operational Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {currentWeekData.content.table.map((row, idx) => (
                      <tr key={idx}>
                        <td><strong>{row.team}</strong></td>
                        <td>{row.responsibility}</td>
                        <td>
                          <span className={`status-dot ${row.status.toLowerCase().replace(' ', '-')}`}></span>
                          {row.status}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {currentWeekData.content.code && (
                <>
                  <h4>Engine Integration Snippet</h4>
                  <div className="code-block-wrapper">
                    <div className="code-header">
                      <span>JavaScript Logic / Production Block</span>
                      <button className="copy-btn" onClick={() => alert("Snippet reference tracked in log view.")}>Copy Code</button>
                    </div>
                    <pre><code>{currentWeekData.content.code}</code></pre>
                  </div>
                </>
              )}
            </div>

            <div className="card-footer-notes">
              <p>🔮 <strong>Next Steps Preview:</strong> {activeTab === 4 ? "Official Beta Launch to 10% traffic, real-time Grafana dashboard integrations, final stakeholder validation checkoffs." : "Transitioning dependencies directly into succeeding developmental lifecycle frames."}</p>
            </div>
          </div>
        </main>

        {/* RIGHT COLUMN: INTERACTIVE PROTOTYPE SANDBOX */}
        <aside className="sidebar-area">
          <div className="card chatbot-sandbox">
            <div className="card-header border-b">
              <div>
                <h2>🤖 Prototype Live Testbed</h2>
                <p className="xs-sub">Interact with Alpha Instance (W3 / W4 Stack)</p>
              </div>
              <div className="live-tag">LIVE STABLE</div>
            </div>

            <div className="chat-viewport-body">
              <div className="system-notice">
                <p>💡 <em>System Note: Type 'help' or negative feedback to trigger the automated <strong>Sentiment Analysis Escalation Handler (Threshold &gt; 0.75)</strong> validated in Week 4.</em></p>
              </div>

              {chatMessages.map((msg, idx) => (
                <div key={idx} className={`chat-bubble-row ${msg.sender}`}>
                  <div className={`avatar ${msg.sender}`}>{msg.sender === 'user' ? '👤' : '🤖'}</div>
                  <div className={`chat-bubble ${msg.sender} ${msg.special ? 'escalation-alert' : ''}`}>
                    {msg.text}
                  </div>
                </div>
              ))}
            </div>

            <form onSubmit={handleSendMessage} className="chat-input-footer">
              <input 
                type="text" 
                value={inputMessage} 
                onChange={(e) => setInputMessage(e.target.value)} 
                placeholder="Query chatbot runtime engine..." 
                className="chat-field"
              />
              <button type="submit" className="chat-send-btn">Send</button>
            </form>
          </div>

          <div className="footer-copyright">
            <p>© 2026 Dharmendra Kumar Nayak</p>
            <p>AI Project Management Documentation Engine</p>
          </div>
        </aside>

      </div>
    </div>
  );
}