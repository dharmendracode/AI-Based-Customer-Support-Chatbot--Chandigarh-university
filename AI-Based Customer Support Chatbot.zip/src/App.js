import React, { useState, useEffect, useRef } from 'react';
import './App.css';

// Import the logo file provided in the workspace
import cuLogo from './cu-logo.png'; 

export default function App() {
  // Application Global States
  const [activeTab, setActiveTab] = useState('dashboard'); // 'dashboard' or 'history'
  const [systemLatency, setSystemLatency] = useState(1.2);
  const [accuracyRating, setAccuracyRating] = useState(92);
  const [humanHandOffs, setHumanHandOffs] = useState(0);
  const [totalQueries, setTotalQueries] = useState(24);
  
  // Interactive Chat Engine States
  const [messages, setMessages] = useState([
    { id: 1, text: "System Initialize... Connected to Vector DB Core.", sender: "system", timestamp: "19:35" },
    { id: 2, text: "Hello! I am your AI Support Assistant powered by Chandigarh University's RAG Pipeline. How can I help you today?", sender: "bot", timestamp: "19:36" }
  ]);
  const [userInput, setUserInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [sentimentHistory, setSentimentHistory] = useState([]);
  
  const chatEndRef = useRef(null);

  // Auto-scroll chat view container on updates
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Mock Sentiment Analyzer & Knowledge Retrieval Emulation Core
  const processLLMResponse = (query) => {
    const lowerQuery = query.toLowerCase();
    let responseText = "";
    let detectedSentiment = 0.0; // 0 is neutral, negative values indicate frustration

    // 1. Analyze Sentiment Score (Week 4 Specification Matrix)
    if (lowerQuery.includes("bad") || lowerQuery.includes("worst") || lowerQuery.includes("angry") || lowerQuery.includes("frustrated") || lowerQuery.includes("stupid")) {
      detectedSentiment = -0.85; // Exceeds the critical -0.75 threshold
    } else if (lowerQuery.includes("slow") || lowerQuery.includes("error") || lowerQuery.includes("wait")) {
      detectedSentiment = -0.40;
    } else if (lowerQuery.includes("thank") || lowerQuery.includes("good") || lowerQuery.includes("awesome")) {
      detectedSentiment = 0.90;
    }

    // Update historical sentiment evaluation logs
    setSentimentHistory(prev => [detectedSentiment, ...prev]);

    // 2. RAG Gateway Match Tree (Weeks 1-3 Context Rules)
    if (detectedSentiment <= -0.75) {
      // Hard trigger routing logic for human agent escalation handoff
      setHumanHandOffs(prev => prev + 1);
      responseText = "🚨 [CRITICAL SENTIMENT THRESHOLD EXCEEDED: " + detectedSentiment + "] I apologize for the trouble. I'm connecting you to a live customer service specialist right now.";
      return { text: responseText, isEscalation: true };
    }

    if (lowerQuery.includes("week 1") || lowerQuery.includes("planning") || lowerQuery.includes("scope")) {
      responseText = "According to Dharmendra's Week 1 files: The core project objective targets 24/7 automation availability and reducing baseline ticket load volumes via ground truth FAQ data sets.";
    } else if (lowerQuery.includes("week 3") || lowerQuery.includes("rag") || lowerQuery.includes("api") || lowerQuery.includes("fastapi")) {
      responseText = "RAG Core Pipeline status: Operational. Successfully bound FastAPI routing schemas to Pinecone/ChromaDB indexing clusters for contextual lookups.";
    } else if (lowerQuery.includes("week 4") || lowerQuery.includes("test") || lowerQuery.includes("kpi")) {
      responseText = "Week 4 Quality Validation KPIs: 92% retrieval relevance logic precision, average latency speed clocking at 1.2s, and 100% human routing handover precision loops.";
    } else if (lowerQuery.includes("hello") || lowerQuery.includes("hi")) {
      responseText = "Hello! Request successfully processed. You can query me on historical chat matrix logs, API code snippets, or system parameters.";
    } else if (lowerQuery.includes("code") || lowerQuery.includes("javascript")) {
      responseText = "Core endpoint gateway logic: `fetch('http://api.chatbot.internal/chat', {method: 'POST'})`. This safely routes JSON packet blocks into our back-end model processors.";
    } else {
      responseText = "Context parsed successfully. Knowledge Base Search: Matched relevant records with " + accuracyRating + "% precision. System is stable and preparing for the 10% Live Traffic Beta Deployment stage.";
    }

    return { text: responseText, isEscalation: false };
  };

  // Submit Handler for sending message text
  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!userInput.trim()) return;

    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const currentQuery = userInput;
    
    // Append User message node
    setMessages(prev => [...prev, { id: Date.now(), text: currentQuery, sender: "user", timestamp }]);
    setUserInput("");
    setIsTyping(true);
    setTotalQueries(prev => prev + 1);

    // Dynamic latency fluctuation to look realistic
    const simulatedLatency = parseFloat((1.0 + Math.random() * 0.5).toFixed(2));
    setSystemLatency(simulatedLatency);

    // Trigger LLM model response evaluation delay
    setTimeout(() => {
      const result = processLLMResponse(currentQuery);
      setIsTyping(false);
      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: result.text,
        sender: "bot",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        special: result.isEscalation
      }]);
    }, simulatedLatency * 1000);
  };

  return (
    <div className="app-workspace">
      
      {/* 1. ADMIN SYSTEM CONTROL CONSOLE (LEFT SIDEBAR) */}
      <section className="control-console">
        
        {/* Institutional Branding Block */}
        <div className="branding-wrapper">
          <img src={cuLogo} alt="Chandigarh University Logo" className="branding-logo" />
          <div className="branding-text">
            <h3>AI CONTROL DASHBOARD</h3>
            <p>Lead Engineer: <span className="highlight-name">Dharmendra Kumar Nayak (dhamerda)</span></p>
          </div>
        </div>

        {/* Global Cluster Status Indicators */}
        <div className="system-status-ribbon">
          <div className="status-indicator">
            <span className="pulse-dot active"></span>
            <p>MODEL: <strong>RAG ACTIVE</strong></p>
          </div>
          <div className="status-indicator">
            <span className="pulse-dot tracking"></span>
            <p>STAGE: <strong>UAT VALIDATION</strong></p>
          </div>
        </div>

        {/* Performance Metric Dynamic Cards */}
        <div className="telemetry-grid">
          <div className="telemetry-card">
            <h5>RAG ACCURACY</h5>
            <h4>{accuracyRating}%</h4>
            <div className="meter-track"><div className="meter-fill green" style={{width: `${accuracyRating}%`}}></div></div>
          </div>
          <div className="telemetry-card">
            <h5>AVG LATENCY</h5>
            <h4>{systemLatency}s</h4>
            <div className="meter-track"><div className="meter-fill blue" style={{width: `${(systemLatency / 2) * 100}%`}}></div></div>
          </div>
          <div className="telemetry-card">
            <h5>HANDOFF COUNT</h5>
            <h4>{humanHandOffs}</h4>
            <p className="xs-caption">Sentiment limit &lt; -0.75</p>
          </div>
          <div className="telemetry-card">
            <h5>TOTAL QUERIES</h5>
            <h4>{totalQueries}</h4>
            <p className="xs-caption">Live pipeline testing</p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="console-navigation">
          <button className={`nav-btn ${activeTab === 'dashboard' ? 'active' : ''}`} onClick={() => setActiveTab('dashboard')}>
            📂 Project Documentation Specs
          </button>
          <button className={`nav-btn ${activeTab === 'history' ? 'active' : ''}`} onClick={() => setActiveTab('history')}>
            🛡️ Sentiment Logs & Rules
          </button>
        </div>

        {/* Dynamic Context Block Viewport */}
        <div className="console-viewport">
          {activeTab === 'dashboard' ? (
            <div className="view-content fade-in">
              <h4>System Operational Directives</h4>
              <ul className="doc-bullets">
                <li><strong>Week 1 Initial Scope:</strong> Automation boundaries established. Mapping historic logs to structure ground truths.</li>
                <li><strong>Week 3 Core Architecture:</strong> Successfully bound FastAPIs asynchronous routers with operational vector DB frames.</li>
                <li><strong>Week 4 Current Phase:</strong> Rigorously measuring retrieval accuracy thresholds and tuning NLP orchestration temperature layers.</li>
              </ul>
              
              <div className="snippet-container">
                <div className="snippet-header">Handoff Validation Formula</div>
                <pre><code>{`if (sentimentScore < -0.75 || retryCount > 3) {
  await triggerHumanAgentHandoff(sessionId);
  return "Connecting to specialist...";
}`}</code></pre>
              </div>
            </div>
          ) : (
            <div className="view-content fade-in">
              <h4>Real-Time Sentiment Monitoring Tracker</h4>
              <p className="section-intro">Evaluating downstream chat arrays for frustration signals.</p>
              
              <div className="sentiment-history-list">
                {sentimentHistory.length === 0 ? (
                  <p className="empty-notice">No processed inputs stored in transient validation cache yet.</p>
                ) : (
                  sentimentHistory.map((score, index) => (
                    <div key={index} className={`sentiment-pill ${score < -0.75 ? 'alert' : score > 0 ? 'good' : 'neutral'}`}>
                      <span>Query Layer index [-{index}]</span>
                      <strong>Score: {score.toFixed(2)}</strong>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        <div className="console-footer">
          <p>© 2026 Dharmendra Kumar Nayak | All Rights Reserved</p>
        </div>
      </section>

      {/* 2. CHATBOT LIVE RUNTIME PLAYGROUND (RIGHT PANEL) */}
      <section className="chatbot-terminal">
        <div className="terminal-header">
          <div className="terminal-meta">
            <h4>CUSTOMER SUPPORT AI ENDPOINT</h4>
            <span className="pill-badge active">PROTOTYPE ONLINE</span>
          </div>
          <button className="clear-btn" onClick={() => setMessages([{ id: 1, text: "System memory flushed and re-indexed.", sender: "system", timestamp: "Now" }])}>
            Reset Engine Memory
          </button>
        </div>

        {/* Message Rendering Streams */}
        <div className="terminal-messages-container">
          {messages.map((msg) => (
            <div key={msg.id} className={`message-wrapper ${msg.sender}`}>
              {msg.sender !== 'system' && (
                <div className="message-avatar">
                  {msg.sender === 'bot' ? '🤖' : '👤'}
                </div>
              )}
              
              <div className={`message-bubble ${msg.sender} ${msg.special ? 'escalated' : ''}`}>
                <p className="message-body">{msg.text}</p>
                <span className="message-time">{msg.timestamp}</span>
              </div>
            </div>
          ))}

          {/* Typing Indicator Status */}
          {isTyping && (
            <div className="message-wrapper bot">
              <div className="message-avatar">🤖</div>
              <div className="message-bubble bot typing">
                <span className="dot"></span><span className="dot"></span><span className="dot"></span>
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Interactive Input Entry Controls */}
        <form onSubmit={handleSendMessage} className="terminal-input-bar">
          <input 
            type="text" 
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            placeholder="Type your message... (Try mentioning 'Week 3', 'Code', or send 'Angry feedback' to test handoffs)"
            className="input-field"
          />
          <button type="submit" className="send-action-btn">
            Execute Query
          </button>
        </form>
      </section>

    </div>
  );
}